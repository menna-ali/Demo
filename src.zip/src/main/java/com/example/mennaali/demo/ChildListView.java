package com.example.mennaali.demo;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

/**
 * Created by MennaAli on 10/15/16.
 */
public class ChildListView extends ExpandableListView {

        //dynamically created expandable list view

        public ChildListView(Context context) {

            super(context);

        }

        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            //999999 is a size in pixels. ExpandableListView requires a maximum height in order to do measurement calculations.
            heightMeasureSpec = MeasureSpec.makeMeasureSpec(999999, MeasureSpec.AT_MOST);
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);


        }
    }
