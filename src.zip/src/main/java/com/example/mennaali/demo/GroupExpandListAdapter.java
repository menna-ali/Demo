package com.example.mennaali.demo;

import java.util.ArrayList;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

/**
 * Created by MennaAli on 10/14/16.
 */
public class GroupExpandListAdapter extends BaseExpandableListAdapter {

        private Context context;
        private ArrayList<Group> groups;
        private int parentPosition;

        public GroupExpandListAdapter(Context context, ArrayList<Group> groups, int parentPosition) {
            this.context = context;
            this.groups = groups;
            this.parentPosition = parentPosition;
        }

        @Override
        public Object getChild(int groupPosition, int childPosition) {

            // this function retrieves only 6 images children at a time from the list of 12 images, according to the parent position
            // i.e. whether this is the inisde main 1 or main 2
            ArrayList<Child> chList = groups.get(groupPosition).getItems();
           ArrayList<Child> subChList = new ArrayList<Child>();

            switch(parentPosition)
            {
                case 0:
                    for(int i = 0; i < chList.size()/2; i++)
                        subChList.add(chList.get(i));
                    break;
                case 1:
                    for(int i = chList.size()/2 ; i < chList.size(); i++)
                        subChList.add(chList.get(i));
                    break;
            }
            return subChList.get(childPosition);


        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition,
                                 boolean isLastChild, View convertView, ViewGroup parent) {

            Child child = (Child) getChild(groupPosition, childPosition);
            if (convertView == null) {
                LayoutInflater infalInflater = (LayoutInflater) context
                        .getSystemService(context.LAYOUT_INFLATER_SERVICE);
                convertView = infalInflater.inflate(R.layout.child_item, null);
            }
            ImageView iv = (ImageView) convertView.findViewById(R.id.image);

            iv.setImageBitmap(child.getBitmap());

            return convertView;
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            ArrayList<Child> chList = groups.get(groupPosition).getItems();
            return chList.size()/2;
        }

        @Override
        public Object getGroup(int groupPosition) {
            return groups.get(groupPosition);
        }

        @Override
        public int getGroupCount() {
            return groups.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded,
                                 View convertView, ViewGroup parent) {
            Group group = (Group) getGroup(groupPosition);
            if (convertView == null) {
                LayoutInflater inf = (LayoutInflater) context
                        .getSystemService(context.LAYOUT_INFLATER_SERVICE);
                convertView = inf.inflate(R.layout.group_item, null);
            }
            TextView tv = (TextView) convertView.findViewById(R.id.group_name);
             tv.setText(group.getNames().get(groupPosition));
            return convertView;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

    }

