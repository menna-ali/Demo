package com.example.mennaali.demo;

/**
 * Created by MennaAli on 10/14/16.
 */
import java.util.ArrayList;

public class Group {

    /*
    - Main 1        parent name             parent
        Sub1          names[0]              subgroup
         img1           items[0]
         img2           item[1]              Children
         img3           items[2]
        Sub2          names[1]              subgroup
         img4           items[3]
         img5           items[4]            Children
         img6           items[5]

          this is the structure of one group object. Items is an array list of children (bitmap objects and their paths)
     */
    private String parentName;
    private ArrayList<String> Names;
    private ArrayList<Child> Items;

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public ArrayList<String> getNames() {
        return Names;
    }

    public void setNames(ArrayList<String> names) {
        this.Names = names;
    }

    public ArrayList<Child> getItems() {
        return Items;
    }

    public void setItems(ArrayList<Child> Items) {
        this.Items = Items;
    }

}