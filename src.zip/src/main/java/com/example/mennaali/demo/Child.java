package com.example.mennaali.demo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

/**
 * Created by MennaAli on 10/14/16.
 */
public class Child {

    /*
    A Child object is a bitmap associated with its path on the phone's external storage
     */
    private String path;
    private Bitmap currentBitmap;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setBitmap(String path)
    {
        // mutable bitmaps allows bitmap edits
        // all bitmaps are subsampled in order to enhance the program performance
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inMutable = true;
        options.inSampleSize = 4;
        if (currentBitmap != null) {
            currentBitmap.recycle();
            currentBitmap = null;
        }
        currentBitmap = BitmapFactory.decodeFile(path, options);

    }

    public void setBitmap(Bitmap b)
    {
        currentBitmap = b;

    }

    public Bitmap getBitmap()
    {
        return currentBitmap;
    }
}
