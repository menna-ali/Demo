package com.example.mennaali.demo;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by MennaAli on 10/15/16.
 */
public class ParentExpandListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private ArrayList<Group> groups;

    public ParentExpandListAdapter(Context context, ArrayList<Group> groups) {
        this.context = context;
        this.groups = groups;
    }

    @Override
    public Object getChild(int arg0, int arg1) {
        return arg1;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {


        // in order to nest expandable list view, I dynamically created a new list view object to be the child of the parent
        // list view, which contains only the main 1 and main 2 lists. The new sublists show the subgroups and their children
        ChildListView secondLevel;

        if (convertView == null)
            secondLevel = new ChildListView(context);

        else
            secondLevel = (ChildListView) convertView;

        final GroupExpandListAdapter secondLevelAdapter = new GroupExpandListAdapter(context, groups, groupPosition);
        secondLevel.setAdapter(secondLevelAdapter);

        // if an image is selected at anytime, send the path of that image to the next activity and start it
        secondLevel.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {

                Child selectedChild = (Child) secondLevelAdapter.getChild(groupPosition, childPosition);
                String bitmapPath = selectedChild.getPath();
                Intent intent = new Intent(context, DisplayActivity.class);
                intent.putExtra("path", bitmapPath);
                context.startActivity(intent);

                return false;


            }
        });

        return secondLevel;
    }

    @Override
    public int getChildrenCount(int groupPosition) {

        //each parent has on subgroup list which has two children
        return 1;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return groups.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return groups.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.parent_item, null);
        }

        TextView text = (TextView) convertView.findViewById(R.id.parent_name);
        text.setText(groups.get(groupPosition).getParentName());
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}