package com.example.mennaali.demo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ExpandableListView;

import java.util.ArrayList;


public class DisplayActivity extends Activity {


    // in this activity, the three planes of an image are displayed inside expandable list view
    private ChildExpandListAdapter ExpAdapter;
    private ArrayList<Group> ExpListItems;
    private ExpandableListView ExpandList;
    private Intent i;
    private String path;
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        // the path of the image is passed from the previous activity
        // image needs to be resynthesized
        i = getIntent();
        path = i.getStringExtra("path");

        // mutable bitmaps allows bitmap edits
        // all bitmaps are subsampled in order to enhance the program performance
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inMutable = true;
        options.inSampleSize = 4;
        bitmap = BitmapFactory.decodeFile(path, options);

        //set the expandable list view groups inisde an async task; processing large images might take some time
        ExpandList = (ExpandableListView) findViewById(R.id.exp_list);
        GetPlane getplane = new GetPlane();
        getplane.execute(path);

    }

    private class GetPlane extends AsyncTask<String, Void, Void > {

        // display progress dialog
        ProgressDialog PD;
        @Override
        protected void onPreExecute() {
            PD= ProgressDialog.show(DisplayActivity.this,null, "Please Wait...", true);
            PD.setCancelable(true);
        }

        @Override
        protected Void doInBackground(String... params) {

            // set expandable list objects; a title paired with an image
            ExpListItems = SetGroups();
            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            //dismiss dialog and set list adapter
            PD.dismiss();
            ExpAdapter = new ChildExpandListAdapter(DisplayActivity.this, ExpListItems);
            ExpandList.setAdapter(ExpAdapter);
        }
    }



    /*
        function getPlane receives a bitmap and according to the flag it receives, it returns either the r, g, or b plane of the image
     */
    private Bitmap getPlane(Bitmap b, int flag)
    {
        //create a copy of the original bitmap to avoid propagating changes between function calls
        // default mask value is 0xffffffff
        Bitmap edit = b.copy(b.getConfig(), true);
        int mask = 0xffffffff;

        //switch on the flag value: 0 -> red plane, 1 -> green plane, 2 -> blue plane
        //the mask always starts with 0xff to preserve the alpha value, then remaining bits are changed depending on which plane to be extracted
        switch (flag)
        {
            case 0:
                mask = 0xffff0000;
                break;
            case 1:
                mask = 0xff00ff00;
                break;
            case 2:
                mask = 0xff0000ff;
                break;
        }

        //loop through the image, get pixel value, apply mask and return desired plane
        for ( int i = 0; i < b.getWidth(); i++)
            for (int j = 0; j < b.getHeight(); j++) {
                int pixel = edit.getPixel(i,j);
                pixel = pixel & mask;
                edit.setPixel(i, j, pixel);
            }
        return edit;
    }


    private ArrayList<Group> SetGroups() {

        // create three group objects, set the three group names and add the three planes of the images to each group
        ArrayList<String> group_names = new ArrayList<String>();
        group_names.add("Red");
        group_names.add("Green");
        group_names.add("Blue");
        ArrayList<Bitmap> planes = new ArrayList<Bitmap>();
        ArrayList<Group> list = new ArrayList<Group>();
        ArrayList<Child> ch_list;

        Bitmap r = getPlane(bitmap, 0);
        planes.add(r);
        Bitmap g= getPlane(bitmap, 1);
        planes.add(g);
        Bitmap b = getPlane(bitmap, 2);
        planes.add(b);

        int groupSize = 3;
        int size = 1;
        int j = 0;

        for (int i = 0; i < groupSize; i++ ) {
            Group gru = new Group();
            gru.setNames(group_names);

            ch_list = new ArrayList<Child>();
            for (; j < size; j++) {
                Child ch = new Child();
                ch.setBitmap(planes.get(j));
                ch_list.add(ch);
            }
            gru.setItems(ch_list);
            list.add(gru);

            size = ++size;
        }

        return list;
    }


}
