package com.example.mennaali.demo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Random;

import android.provider.MediaStore;
import android.widget.ExpandableListView;


public class MainActivity extends Activity {

        // launcher activity where 2 main lists are displayed with their sublists and children as expandable list views
        private ArrayList<Group> ExpListItems;
        private ParentExpandListAdapter parentExpAdapter;
        private ExpandableListView parentExpandList;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            // parent exapndable lists: Main 1 and Main 2
            parentExpandList = (ExpandableListView) findViewById(R.id.exp_list);

            // set the images, titles of parent and sub expandable list in an async task; processing large images might take some time
            GetImages getimages = new GetImages();
            getimages.execute();

        }

    private class GetImages extends AsyncTask<String, Void, Void > {

        // display progress dialog
        ProgressDialog PD;
        @Override
        protected void onPreExecute() {
            PD= ProgressDialog.show(MainActivity.this,null, "Please Wait...", true);
            PD.setCancelable(true);
        }

        @Override
        protected Void doInBackground(String... params) {

            //set expandable list parent, sub groups and children
            ExpListItems = SetGroups();
            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            // dismiss progress dialog
            // set list adapter
            PD.dismiss();
            parentExpAdapter = new ParentExpandListAdapter(MainActivity.this, ExpListItems);
            parentExpandList.setAdapter(parentExpAdapter);
        }
    }

    private ArrayList<Group> SetGroups() {


            // list is a group of two elements: each element contains a parent name, two sub group names, and six images
            String parent_names[] = {"Main 1", "Main 2"};
            ArrayList<String> group_names = new ArrayList<String>();
            group_names.add("Sub 1");
            group_names.add("Sub 2");
            ArrayList<Group> list = new ArrayList<Group>();
            ArrayList<Child> ch_list;

            // 2 parents ( main 1 and main 2), six images per parent
            int parentSize = 2;
            int size = 6;
            int j = 0;


            //load images from phone gallery
            String[] projection = new String[]{
                    MediaStore.Images.Media.DATA,
            };

            Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            Cursor cur = getContentResolver().query(images,
                    projection,
                    "",
                    null,
                    ""
            );

            final ArrayList<String> imagesPath = new ArrayList<String>();
            if (cur.moveToFirst()) {

                int dataColumn = cur.getColumnIndex(
                        MediaStore.Images.Media.DATA);
                do {
                    imagesPath.add(cur.getString(dataColumn));
                } while (cur.moveToNext());
            }
            cur.close();


            //get a random index number between 0 and the total number of images
            Random random = new Random();
            final int count = imagesPath.size() + 1;

            for (int i = 0; i < parentSize; i++) {
                // assign parent names, sub groups names and children images
                Group gru = new Group();
                gru.setNames(group_names);
                gru.setParentName(parent_names[i]);

                ch_list = new ArrayList<Child>();
                for (; j < size; j++) {

                    // add the chosen image to the list of children
                    // children are basically bitmap objects and their paths
                    int number = random.nextInt(count);
                    String path = imagesPath.get(number);
                    Child ch = new Child();
                    ch.setPath(path);
                    ch.setBitmap(path);
                    ch_list.add(ch);
                }

                //set group photo to equal to the array of children list and add the group object the list
                gru.setItems(ch_list);
                list.add(gru);

                size = size + 6;
            }

            return list;
        }

    }

